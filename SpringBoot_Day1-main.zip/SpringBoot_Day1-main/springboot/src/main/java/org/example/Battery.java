package org.example;

public class Battery implements Vehicle{
    public void move(){
        System.out.println("Engine B Started");
    }
}
