package org.example;

public interface Vehicle {
    void move();
}
