package org.example;

public class Engine implements Vehicle{
    /*public Engine(){
        System.out.println("object is created");
    }*/
    /*public void startEngine(){
        System.out.println("Engine started");
    }*/
    public void move(){
        System.out.println("Engine A started");
    }
}
