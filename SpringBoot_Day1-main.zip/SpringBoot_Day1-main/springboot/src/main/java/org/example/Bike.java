    package org.example;

    public class Bike {
        private int age;
        private int roll;
        private Vehicle v;

        public Bike(Vehicle v,int age,int roll) {
            this.v = v;
            this.age = age;
            this.roll = roll;
            System.out.println(age);
            System.out.println(roll);
        }

        public void work(){
            v.move();
        }
    }
