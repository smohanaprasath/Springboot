package org.example.config;

import org.example.Student;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Myconfig {
    @Bean(name = "s1")
    public Student ram() {
        return new Student();
    }
    @Bean(name = "s2")
    public Student ramu() {
        return new Student();
    }

}
