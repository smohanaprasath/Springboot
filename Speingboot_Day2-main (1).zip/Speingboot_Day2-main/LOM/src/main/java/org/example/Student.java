package org.example;

public class Student {
    public void write(){
        System.out.println("Hello! folks");
    }
}


